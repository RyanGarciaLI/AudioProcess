clear all; close all; clc;
index = [0, 1, 4, 5, 7, 8];
for i=1:6
    for j=1:6
        fileA = ['s' num2str(index(i),"%d") 'A.wav'];
        fileB = ['s' num2str(index(j),"%d") 'B.wav'];
        value = speechRecog(fileA, fileB);
        fprintf("%7.3f ", value);
    end
    fprintf("\n");
end

