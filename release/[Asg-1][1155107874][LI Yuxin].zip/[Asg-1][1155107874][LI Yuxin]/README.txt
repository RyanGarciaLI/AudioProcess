Author: LI YUXIN
SID: 1155107874

matlab: 2022b

Task 3 and Task 4:
Files required to submit are fourier.txt and lpc10.txt. More details of the whole 
implementation can be reviewed in signalAnaylsis.m, just run it sequentially. I
also defined some utility functions for convenience.


Task 5:
I plotted optimal path by replacing the values of cells within the path by Inf.
See in 'Optimal Path Plot.txt'. You can retrieve the replaced values from the
cells list in the txt file. The cell from upper-right to lower-left are listed 
from top to bottom in the file. I also provided an overview of the path seen in
'optimal path overview.png'. The whole accumulated distortion score matrix can 
be viewed in "accumulation matrix.txt". The confusion table can be seen in 
'confusion table.txt' and 'confusion table.png'. You can rebuild it by executing
'buildConfusion.m'. Please use wav2mfcc1 in the same folder ./mfcc/mfcc/wav2mfcc1.m

In all, all the details can be reviewed by executing speedRecog.